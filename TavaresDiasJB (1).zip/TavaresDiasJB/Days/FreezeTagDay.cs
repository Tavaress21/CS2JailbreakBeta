using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;
using TavaresDiasJB.Utils;
using Timer = CounterStrikeSharp.API.Modules.Timers.Timer;

namespace TavaresDiasJB.Days
{
    /// <summary>
    /// FreezeTag:
    ///  - CTs congelados e imunes 20s enquanto os Ts fogem.
    ///  - Depois disso, CTs recebem faca e têm de "congelar" Ts com facadas (sem dano real).
    ///  - Um T atingido perde 1 de 3 vidas e fica congelado 20s.
    ///  - Se outro T o atingir com faca antes do timer acabar, é resgatado: mantém a vida
    ///    já perdida, fica 2s invulnerável (glow amarelo) e o timer é cancelado.
    ///  - Se o timer chegar a 0 sem resgate, ou as vidas chegarem a 0: morre a sério.
    ///  - CTs são imortais neste dia (todo o dano de faca é anulado).
    ///  - Dia acaba quando só resta 1 T.
    /// </summary>
    public class FreezeTagDay : IDayMode
    {
        public string Name => "FreezeTag";
        public bool IsFinished { get; private set; } = false;

        private readonly Dictionary<int, PlayerDayState> _states;
        private readonly BasePlugin _plugin;
        private readonly Dictionary<int, Timer> _freezeTimeoutTimers = new();
        private readonly Dictionary<int, Timer> _invulnTimers = new();
        private readonly Dictionary<int, Timer> _countdownTimers = new();
        private readonly Dictionary<int, int> _countdownRemaining = new();
        private Timer? _ctFreezeTimer;

        private const float CtFreezeDurationSeconds = 20.0f;
        private const float FrozenTimeoutSeconds = 20.0f;
        private const float RescueInvulnSeconds = 2.0f;
        private const float CountdownIntervalSeconds = 2.0f; // a cada quantos segundos atualiza o contador no chat

        private int _initialAliveTs = 0;

        public FreezeTagDay(Dictionary<int, PlayerDayState> states, BasePlugin plugin)
        {
            _states = states;
            _plugin = plugin;
        }

        public void OnDayStart()
        {
            IsFinished = false;
            _initialAliveTs = Utilities.GetPlayers().Count(p => p.IsValid && p.PawnIsAlive && p.Team == CsTeam.Terrorist);

            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null) continue;

                WeaponUtils.SafeRemoveAllWeapons(player);
                var state = GetState(player);
                state.LivesRemaining = 3;

                if (player.Team == CsTeam.CounterTerrorist)
                {
                    FreezePlayer(player, state);
                }
                else if (player.Team == CsTeam.Terrorist)
                {
                    player.GiveNamedItem("weapon_knife");
                }
            }

            _ctFreezeTimer = _plugin.AddTimer(CtFreezeDurationSeconds, OnCtFreezeEnd);

            ChatUtils.All($"{ChatColors.Purple}FreezeTag ativado! Os CTs estão congelados durante 20 segundos — fujam!");
        }

        private void OnCtFreezeEnd()
        {
            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null || !player.PawnIsAlive) continue;
                if (player.Team != CsTeam.CounterTerrorist) continue;

                var state = GetState(player);
                UnfreezePlayer(player, state);
                player.GiveNamedItem("weapon_knife");
            }

            ChatUtils.CtsReleasedFreezeTag();
        }

        public void OnTick()
        {
            // Reforça o congelamento a cada tick — ver nota em ApplyFreezeMoveType.
            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || !player.PawnIsAlive) continue;

                var state = GetState(player);
                var pawn = player.PlayerPawn.Value;
                if (pawn == null) continue;

                if (state.IsFrozen)
                {
                    ApplyFreezeMoveType(pawn);
                    pawn.Teleport(null, null, new Vector(0, 0, 0)); // zera velocidade residual
                }

                EnforceKnifeOnly(player, pawn);
            }

            CheckEndCondition();
        }

        // Neste dia só deve existir faca. Se alguém apanhar uma arma do chão (largada
        // antes do dia começar, ou de outro jogador morto), removemo-la aqui — é
        // reforçado a cada tick. IMPORTANTE (corrigido após crash em produção):
        // nunca tratamos um DesignerName vazio/nulo como "não é faca, remove" — uma
        // arma recém-criada (ex: mesmo tick de GiveNamedItem) pode ainda não ter o
        // nome preenchido, e destruir a entidade nesse instante causou
        // "FATAL ERROR: WriteEnterPVS: GetEntServerClass failed" no servidor real.
        // Também usamos RemoveItemByDesignerName (mediado pelo controller) em vez de
        // weapon.Remove() direto na entidade, que é a via mais seguramente suportada.
        private void EnforceKnifeOnly(CCSPlayerController player, CCSPlayerPawn pawn)
        {
            var weaponServices = pawn.WeaponServices;
            if (weaponServices == null) return;

            foreach (var weaponHandle in weaponServices.MyWeapons)
            {
                var weapon = weaponHandle.Value;
                if (weapon == null || !weapon.IsValid) continue;

                var designerName = weapon.DesignerName;
                if (string.IsNullOrEmpty(designerName)) continue; // ainda a inicializar — não mexer

                if (!designerName.Contains("knife", StringComparison.OrdinalIgnoreCase))
                {
                    player.RemoveItemByDesignerName(designerName);
                }
            }
        }

        public bool OnPlayerHurt(CCSPlayerController victim, CCSPlayerController? attacker, string weapon, int damage)
        {
            // Neste dia, TODO o dano é cosmético/anulado; a faca nunca mata por dano direto.
            if (attacker == null || attacker.Slot == victim.Slot)
            {
                return true;
            }

            // NOTA: CT e T têm facas com nomes de entidade diferentes (weapon_knife vs
            // weapon_knife_t), e não há garantia de que o evento devolve o nome "puro"
            // sem prefixo. Por isso verificamos se contém "knife" em vez de comparação
            // exata — isto cobre "knife", "weapon_knife", "knife_t", "weapon_knife_t", etc.
            if (!weapon.Contains("knife", StringComparison.OrdinalIgnoreCase))
            {
                return true; // segurança extra: nenhuma outra arma faz efeito
            }

            var victimState = GetState(victim);

            // CT a atingir T
            if (attacker.Team == CsTeam.CounterTerrorist && victim.Team == CsTeam.Terrorist)
            {
                // Já congelado: CT não tem mais influência
                if (victimState.IsFrozen)
                {
                    return true;
                }
                // Em janela de invulnerabilidade pós-resgate
                if (victimState.IsRescueInvulnerable)
                {
                    return true;
                }

                HandleTHit(attacker, victim, victimState);
                return true;
            }

            // T a atingir T congelado = resgate
            if (attacker.Team == CsTeam.Terrorist && victim.Team == CsTeam.Terrorist)
            {
                if (victimState.IsFrozen)
                {
                    RescueTeammate(attacker, victim, victimState);
                }
                return true;
            }

            return true;
        }

        private void HandleTHit(CCSPlayerController attacker, CCSPlayerController victim, PlayerDayState state)
        {
            state.LivesRemaining--;

            if (state.LivesRemaining <= 0)
            {
                KillPlayer(victim);
                ChatUtils.PlayerDiedFromLives(victim.PlayerName);
                ChatUtils.To(attacker, $"{ChatColors.Green}Era a última vida de {ChatColors.Red}{victim.PlayerName}{ChatColors.Green} — eliminado!");
                return;
            }

            FreezePlayer(victim, state);
            ChatUtils.LivesRemaining(victim, state.LivesRemaining);
            ChatUtils.To(attacker, $"{ChatColors.Green}Congelaste {ChatColors.Red}{victim.PlayerName}{ChatColors.Green} — resta(m)-lhe {ChatColors.Yellow}{state.LivesRemaining}{ChatColors.Green} vida(s).");

            // Agenda o "timeout": se ninguém salvar em 20s, morre
            if (_freezeTimeoutTimers.TryGetValue(victim.Slot, out var existing))
            {
                existing.Kill();
            }
            _freezeTimeoutTimers[victim.Slot] = _plugin.AddTimer(FrozenTimeoutSeconds, () => OnFreezeTimeout(victim, state));

            StartCountdownDisplay(victim);
        }

        // Contador visível no chat, só para o jogador congelado, atualizado a cada
        // CountdownIntervalSeconds. Cancela-se sozinho ao chegar a 0, e é cancelado
        // manualmente em caso de resgate, morte, ou fim do dia.
        private void StartCountdownDisplay(CCSPlayerController victim)
        {
            StopCountdownDisplay(victim.Slot);

            int remaining = (int)FrozenTimeoutSeconds;
            _countdownRemaining[victim.Slot] = remaining;
            ChatUtils.To(victim, $"{ChatColors.LightBlue}Congelado! {remaining}s até morreres se ninguém te salvar.");

            _countdownTimers[victim.Slot] = _plugin.AddTimer(CountdownIntervalSeconds, () => TickCountdown(victim),
                CounterStrikeSharp.API.Modules.Timers.TimerFlags.REPEAT);
        }

        private void TickCountdown(CCSPlayerController victim)
        {
            if (!victim.IsValid || !_countdownRemaining.TryGetValue(victim.Slot, out var remaining))
            {
                StopCountdownDisplay(victim.Slot);
                return;
            }

            var state = GetState(victim);
            if (!state.IsFrozen)
            {
                // Foi salvo (ou já morreu) entretanto — para o contador.
                StopCountdownDisplay(victim.Slot);
                return;
            }

            remaining -= (int)CountdownIntervalSeconds;
            if (remaining <= 0)
            {
                StopCountdownDisplay(victim.Slot);
                return; // o timer de timeout (OnFreezeTimeout) trata da morte em si
            }

            _countdownRemaining[victim.Slot] = remaining;
            ChatUtils.To(victim, $"{ChatColors.LightBlue}Congelado! {remaining}s até morreres se ninguém te salvar.");
        }

        private void StopCountdownDisplay(int slot)
        {
            if (_countdownTimers.TryGetValue(slot, out var t))
            {
                t.Kill();
                _countdownTimers.Remove(slot);
            }
            _countdownRemaining.Remove(slot);
        }

        private void OnFreezeTimeout(CCSPlayerController victim, PlayerDayState state)
        {
            StopCountdownDisplay(victim.Slot);
            if (!victim.IsValid || !victim.PawnIsAlive) return;
            if (!state.IsFrozen) return; // já foi salvo entretanto

            KillPlayer(victim);
            ChatUtils.PlayerDiedFromLives(victim.PlayerName);
        }

        private void RescueTeammate(CCSPlayerController rescuer, CCSPlayerController victim, PlayerDayState state)
        {
            if (_freezeTimeoutTimers.TryGetValue(victim.Slot, out var timeoutTimer))
            {
                timeoutTimer.Kill();
                _freezeTimeoutTimers.Remove(victim.Slot);
            }
            StopCountdownDisplay(victim.Slot);

            UnfreezePlayer(victim, state);

            state.IsRescueInvulnerable = true;
            var pawn = victim.PlayerPawn.Value;
            if (pawn != null) RenderUtils.ApplyRescueGlow(pawn);

            if (_invulnTimers.TryGetValue(victim.Slot, out var oldInvuln))
            {
                oldInvuln.Kill();
            }
            _invulnTimers[victim.Slot] = _plugin.AddTimer(RescueInvulnSeconds, () =>
            {
                state.IsRescueInvulnerable = false;
                if (victim.IsValid && victim.PlayerPawn.Value != null)
                {
                    RenderUtils.ResetTint(victim.PlayerPawn.Value);
                }
            });

            ChatUtils.PlayerRescued(rescuer.PlayerName, victim.PlayerName, state.LivesRemaining);
        }

        private void CheckEndCondition()
        {
            if (IsFinished) return;

            int aliveTs = 0;
            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || !player.PawnIsAlive) continue;
                if (player.Team == CsTeam.Terrorist) aliveTs++;
            }

            if (aliveTs <= 1 && aliveTs < _initialAliveTs)
            {
                IsFinished = true;
            }
        }

        public void OnPlayerDeath(CCSPlayerController victim)
        {
            if (_freezeTimeoutTimers.TryGetValue(victim.Slot, out var t))
            {
                t.Kill();
                _freezeTimeoutTimers.Remove(victim.Slot);
            }
            if (_invulnTimers.TryGetValue(victim.Slot, out var it))
            {
                it.Kill();
                _invulnTimers.Remove(victim.Slot);
            }
            StopCountdownDisplay(victim.Slot);
            CheckEndCondition();
        }

        public void OnDayEnd()
        {
            _ctFreezeTimer?.Kill();
            foreach (var timer in _freezeTimeoutTimers.Values) timer.Kill();
            foreach (var timer in _invulnTimers.Values) timer.Kill();
            foreach (var timer in _countdownTimers.Values) timer.Kill();
            _freezeTimeoutTimers.Clear();
            _invulnTimers.Clear();
            _countdownTimers.Clear();
            _countdownRemaining.Clear();

            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null) continue;
                var state = GetState(player);
                RenderUtils.ResetTint(player.PlayerPawn.Value);
                if (state.IsFrozen)
                {
                    UnfreezePlayer(player, state);
                }
                state.IsRescueInvulnerable = false;
            }
        }

        // --- Auxiliares ---

        private void FreezePlayer(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            state.IsFrozen = true;
            ApplyFreezeMoveType(pawn);
            RenderUtils.ApplyIceTint(pawn);
        }

        // NOTA: mudámos de MOVETYPE_NONE para MOVETYPE_WALK — um jogador com
        // MOVETYPE_NONE aparenta dar uma resposta de colisão diferente a quem lhe
        // salta em cima (bug relatado: "T em cima de T congelado não consegue
        // saltar"), possivelmente relacionado com um problema antigo e conhecido do
        // motor Source ("stuck on object"). Com MOVETYPE_WALK, o congelamento em si
        // continua garantido porque forçamos posição/velocidade a zero a cada tick
        // (ver OnTick) — só a física de colisão para quem está por cima é que muda.
        // NOTA: tentámos MOVETYPE_WALK para resolver "não consigo saltar em cima de T
        // congelado", mas isso partiu o congelamento em si (Ts conseguiam mexer-se).
        // Revertido para MOVETYPE_NONE — a imobilização é mais importante do que o
        // problema do salto, que fica como limitação conhecida por agora.
        private void ApplyFreezeMoveType(CCSPlayerPawn pawn)
        {
            pawn.MoveType = MoveType_t.MOVETYPE_NONE;
            Utilities.SetStateChanged(pawn, "CBaseEntity", "m_MoveType");
            pawn.ActualMoveType = MoveType_t.MOVETYPE_NONE;
        }

        private void UnfreezePlayer(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            state.IsFrozen = false;
            pawn.MoveType = MoveType_t.MOVETYPE_WALK;
            Utilities.SetStateChanged(pawn, "CBaseEntity", "m_MoveType");
            pawn.ActualMoveType = MoveType_t.MOVETYPE_WALK;
            RenderUtils.ResetTint(pawn);
        }

        private void KillPlayer(CCSPlayerController player)
        {
            // CommitSuicide está disponível na maioria das versões do CS#;
            // se a tua versão não tiver, substitui por player.PlayerPawn.Value.Health = 0
            // seguido de um damage/kill via Server command.
            player.CommitSuicide(false, true);
        }

        private PlayerDayState GetState(CCSPlayerController player)
        {
            if (!_states.TryGetValue(player.Slot, out var state))
            {
                state = new PlayerDayState();
                _states[player.Slot] = state;
            }
            return state;
        }
    }
}
