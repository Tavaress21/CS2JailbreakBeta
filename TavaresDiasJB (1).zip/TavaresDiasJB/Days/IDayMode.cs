using CounterStrikeSharp.API.Core;

namespace TavaresDiasJB.Days
{
    /// <summary>
    /// Contrato que qualquer Special Day tem de cumprir.
    /// O TavaresDiasJB trata do menu, do estado "dia ativo" e chama estes
    /// métodos nos momentos certos.
    /// </summary>
    public interface IDayMode
    {
        string Name { get; }

        /// <summary>Chamado uma vez quando o dia é ativado pelo Warden.</summary>
        void OnDayStart();

        /// <summary>Chamado a cada tick do servidor enquanto o dia está ativo.</summary>
        void OnTick();

        /// <summary>Chamado quando um jogador morre (para verificar condições de fim de dia).</summary>
        void OnPlayerDeath(CCSPlayerController victim);

        /// <summary>
        /// Chamado quando um jogador leva dano (event player_hurt).
        /// Retorna true se o dia já tratou o dano (ex: anulou-o e aplicou lógica própria).
        /// </summary>
        bool OnPlayerHurt(CCSPlayerController victim, CCSPlayerController? attacker, string weapon, int damage);

        /// <summary>Chamado quando o dia termina (condição de fim atingida ou ronda acaba).</summary>
        void OnDayEnd();

        /// <summary>Se true, o TavaresDiasJB encerra o dia e volta ao comportamento normal.</summary>
        bool IsFinished { get; }
    }
}
