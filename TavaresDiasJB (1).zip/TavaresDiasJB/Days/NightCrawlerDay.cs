using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;
using TavaresDiasJB.Utils;
using Timer = CounterStrikeSharp.API.Modules.Timers.Timer;

namespace TavaresDiasJB.Days
{
    /// <summary>
    /// NightCrawler:
    ///  - Ts congelados e imunes a dano durante 30s.
    ///  - CTs ficam 100% invisíveis enquanto parados, com velocidade extra e capacidade
    ///    de "wallhang" (agarrar-se a paredes) desde o início do dia.
    ///  - Aos 30s: Ts descongelam e recebem AK47+Deagle+faca; CTs recebem apenas faca.
    ///  - Dia acaba quando só resta 1 T ou todos os CTs morrem.
    /// </summary>
    public class NightCrawlerDay : IDayMode
    {
        public string Name => "NightCrawler";
        public bool IsFinished { get; private set; } = false;

        private readonly Dictionary<int, PlayerDayState> _states;
        private readonly BasePlugin _plugin;
        private bool _weaponsGiven = false;
        private Timer? _freezeTimer;

        // Configurações ajustáveis (afinar em testes no servidor)
        private const float StationaryVelocityThreshold = 10.0f; // ups; abaixo disto = "parado"
        private const float SpeedBoostMultiplier = 1.5f; // sobe/desce este valor para afinar o "muito mais rápido"
        private const float FreezeDurationSeconds = 30.0f;
        private const float WallHangLaunchSpeed = 380.0f; // reduzido de 550 a pedido — ajusta se ainda estiver rápido/lento

        private int _initialAliveTs = 0;

        public NightCrawlerDay(Dictionary<int, PlayerDayState> states, BasePlugin plugin)
        {
            _states = states;
            _plugin = plugin;
        }

        public void OnDayStart()
        {
            IsFinished = false;
            _weaponsGiven = false;
            _initialAliveTs = Utilities.GetPlayers().Count(p => p.IsValid && p.PawnIsAlive && p.Team == CsTeam.Terrorist);

            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null) continue;

                WeaponUtils.SafeRemoveAllWeapons(player);
                var state = GetState(player);

                if (player.Team == CsTeam.Terrorist)
                {
                    FreezePlayer(player, state);
                }
                else if (player.Team == CsTeam.CounterTerrorist)
                {
                    state.HasWallHangAbility = true;
                    ApplySpeedBoost(player);
                }
            }

            // Timer de 30s para descongelar os Ts e distribuir armas
            _freezeTimer = _plugin.AddTimer(FreezeDurationSeconds, OnFreezeEnd);

            ChatUtils.All($"{ChatColors.Purple}NightCrawler ativado! Os Ts estão congelados durante 30 segundos.");
        }

        private void OnFreezeEnd()
        {
            if (_weaponsGiven) return; // segurança, não repetir se o dia já tiver acabado
            _weaponsGiven = true;

            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null || player.PawnIsAlive == false) continue;

                var state = GetState(player);

                if (player.Team == CsTeam.Terrorist)
                {
                    UnfreezePlayer(player, state);
                    player.GiveNamedItem("weapon_knife");
                    player.GiveNamedItem("weapon_ak47");
                    player.GiveNamedItem("weapon_deagle");
                }
                else if (player.Team == CsTeam.CounterTerrorist)
                {
                    player.GiveNamedItem("weapon_knife");

                    // Aplica o esconder logo aqui, no mesmo tick em que a faca é
                    // entregue — sem esperar pelo próximo OnTick — para não haver
                    // sequer 1 frame em que o CT ainda invisível/parado mostra a
                    // faca acabada de dar (ver nota em HandleInvisibility/RenderUtils).
                    var pawn = player.PlayerPawn.Value;
                    if (pawn != null && state.HasWallHangAbility && !state.IsCurrentlyHanging)
                    {
                        var vel = pawn.AbsVelocity;
                        bool stationary = VectorLength(vel) < StationaryVelocityThreshold;
                        if (stationary)
                        {
                            HideOrShowAllWeapons(pawn, true);
                        }
                    }
                    else if (pawn != null && state.IsCurrentlyHanging)
                    {
                        HideOrShowAllWeapons(pawn, true);
                    }
                }
            }

            ChatUtils.CrawlersReleased();
        }

        public void OnTick()
        {
            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null || !player.PawnIsAlive) continue;

                var state = GetState(player);

                if (state.IsFrozen)
                {
                    // Reforça o congelamento a cada tick — ver nota em ApplyFreezeMoveType.
                    var pawn = player.PlayerPawn.Value;
                    ApplyFreezeMoveType(pawn);
                    pawn.Teleport(null, null, new Vector(0, 0, 0));
                    continue;
                }

                if (player.Team == CsTeam.CounterTerrorist && state.HasWallHangAbility)
                {
                    ApplySpeedBoost(player); // reaplicado a cada tick: o jogo reset este campo por conta própria
                    HandleInvisibility(player, state);
                    HandleWallHang(player, state);
                }
            }

            CheckEndCondition();
        }

        private void HandleInvisibility(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            // Enquanto agarrado, é sempre invisível — não depende da leitura de
            // velocidade (que era o que falhava quando o wallhang não segurava bem).
            bool shouldBeInvisible;
            if (state.IsCurrentlyHanging)
            {
                shouldBeInvisible = true;
            }
            else
            {
                var vel = pawn.AbsVelocity;
                float speed = VectorLength(vel);
                shouldBeInvisible = speed < StationaryVelocityThreshold;
            }

            if (shouldBeInvisible)
            {
                RenderUtils.MakeFullyInvisible(pawn);
            }
            else
            {
                RenderUtils.MakeFullyVisible(pawn);
            }

            // A arma (faca) é uma entidade própria, separada do corpo do jogador.
            // Ver a nota grande em RenderUtils.HideWeaponCompletely para o histórico
            // do bug "dá para ver a faca quando és o CT invisível" e porque é preciso
            // mais do que só DisableDraw/EnableDraw para resolver isto por completo.
            HideOrShowAllWeapons(pawn, shouldBeInvisible);
        }

        private static void HideOrShowAllWeapons(CCSPlayerPawn pawn, bool hide)
        {
            var weaponServices = pawn.WeaponServices;
            if (weaponServices == null) return;

            foreach (var weaponHandle in weaponServices.MyWeapons)
            {
                var weapon = weaponHandle.Value;
                if (weapon == null || !weapon.IsValid) continue;

                if (hide)
                {
                    RenderUtils.HideWeaponCompletely(weapon);
                }
                else
                {
                    RenderUtils.ShowWeaponNormally(weapon);
                }
            }
        }

        private void ApplySpeedBoost(CCSPlayerController player)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;
            // VelocityModifier é o campo usado por vários plugins CS# para dar
            // boost de velocidade sem tocar em sv_cheats/cvars globais.
            pawn.VelocityModifier = SpeedBoostMultiplier;
        }

        // --- WallHang ---
        // Redesenhado como toggle manual, sem deteção de colisão/parede nenhuma
        // (decisão tomada depois de a heurística anterior se ter revelado demasiado
        // instável, e de a alternativa robusta — trace real via lib de terceiros —
        // exigir instalação de um módulo nativo no servidor que ficou decidido não
        // valer a pena). Comportamento: segurar E no ar agarra-te no sítio onde estás;
        // premir Espaço solta e dá um impulso na direção da mira.
        private void HandleWallHang(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            var buttons = player.Buttons;
            bool onGround = (pawn.Flags & (uint)PlayerFlags.FL_ONGROUND) != 0;
            bool tryingToUse = (buttons & PlayerButtons.Use) != 0;

            if (state.IsCurrentlyHanging)
            {
                // Largar o E solta imediatamente (sem impulso — cai naturalmente).
                if (!tryingToUse)
                {
                    ReleaseHang(state);
                    return;
                }

                // Mantém o jogador preso no sítio (equivalente ao client_PostThink do 1.6).
                if (state.HangOrigin != null)
                {
                    pawn.Teleport(state.HangOrigin, null, new Vector(0, 0, 0));
                }

                // IN_JUMP enquanto ainda seguras E: dá um impulso para subir/saltar.
                if ((buttons & PlayerButtons.Jump) != 0)
                {
                    Detach(player, state, pawn);
                }
                return;
            }

            // Ainda não está agarrado: E no ar agarra imediatamente, sem verificar parede.
            if (tryingToUse && !onGround)
            {
                var currentOrigin = pawn.AbsOrigin ?? new Vector();
                Attach(player, state, pawn, currentOrigin);
            }
        }

        // Largar o E — diferente de Detach(): não dá impulso nenhum, só para de
        // segurar a posição e deixa a física normal (gravidade) retomar.
        private void ReleaseHang(PlayerDayState state)
        {
            state.IsCurrentlyHanging = false;
            state.HangOrigin = null;
        }

        private void Attach(CCSPlayerController player, PlayerDayState state, CCSPlayerPawn pawn, Vector origin)
        {
            state.IsCurrentlyHanging = true;
            state.HangOrigin = origin;
            // Zera a velocidade via Teleport (mutar pawn.AbsVelocity.X/Y/Z diretamente não tem
            // garantia de escrever na memória do jogo — Teleport é o padrão documentado do CS#).
            pawn.Teleport(null, null, new Vector(0, 0, 0));
        }

        private void Detach(CCSPlayerController player, PlayerDayState state, CCSPlayerPawn pawn)
        {
            state.IsCurrentlyHanging = false;
            state.HangOrigin = null;

            // Lança o jogador na direção para onde está a olhar (equivalente ao
            // velocity_by_aim do 1.6)
            var angles = pawn.EyeAngles;
            var forward = AnglesToForward(angles);
            var launchVelocity = new Vector(forward.X * WallHangLaunchSpeed, forward.Y * WallHangLaunchSpeed, 200.0f);
            pawn.Teleport(null, null, launchVelocity);
        }

        private void CheckEndCondition()
        {
            if (IsFinished) return;

            int aliveTs = 0, aliveCts = 0;
            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || !player.PawnIsAlive) continue;
                if (player.Team == CsTeam.Terrorist) aliveTs++;
                else if (player.Team == CsTeam.CounterTerrorist) aliveCts++;
            }

            // Só termina se o número de Ts vivos realmente desceu desde o início do dia
            // (evita terminar instantaneamente quando o servidor já começa com 1 T só).
            if ((aliveTs <= 1 && aliveTs < _initialAliveTs) || aliveCts == 0)
            {
                IsFinished = true;
            }
        }

        public void OnPlayerDeath(CCSPlayerController victim)
        {
            CheckEndCondition();
        }

        public bool OnPlayerHurt(CCSPlayerController victim, CCSPlayerController? attacker, string weapon, int damage)
        {
            var state = GetState(victim);
            // Ts congelados são imunes a dano durante o freeze inicial
            if (state.IsFrozen)
            {
                return true; // dano será anulado pelo plugin principal
            }
            return false;
        }

        public void OnDayEnd()
        {
            _freezeTimer?.Kill();

            foreach (var player in Utilities.GetPlayers())
            {
                if (!player.IsValid || player.PlayerPawn.Value == null) continue;

                var pawn = player.PlayerPawn.Value;
                var state = GetState(player);

                RenderUtils.MakeFullyVisible(pawn);
                RenderUtils.ResetTint(pawn);
                HideOrShowAllWeapons(pawn, false);
                pawn.VelocityModifier = 1.0f;

                if (state.IsFrozen)
                {
                    UnfreezePlayer(player, state);
                }
                state.IsCurrentlyHanging = false;
                state.HangOrigin = null;
            }
        }

        // --- Auxiliares ---

        private void FreezePlayer(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            state.IsFrozen = true;
            ApplyFreezeMoveType(pawn);
            RenderUtils.ApplyIceTint(pawn);
            state.IsIceTinted = true;
        }

        // NOTA: mesmo problema documentado no FreezeTagDay — "MoveType" sozinho é
        // frequentemente reposto pelo próprio jogo. Mexemos também em "ActualMoveType"
        // e isto é chamado A CADA TICK (ver OnTick), não só uma vez ao congelar.
        private void ApplyFreezeMoveType(CCSPlayerPawn pawn)
        {
            pawn.MoveType = MoveType_t.MOVETYPE_NONE;
            Utilities.SetStateChanged(pawn, "CBaseEntity", "m_MoveType");
            // m_nActualMoveType confirmado NÃO networked (visto no log real do servidor)
            // — SetStateChanged nele só gera aviso sem função, por isso já não o chamamos.
            pawn.ActualMoveType = MoveType_t.MOVETYPE_NONE;
        }

        private void UnfreezePlayer(CCSPlayerController player, PlayerDayState state)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            state.IsFrozen = false;
            pawn.MoveType = MoveType_t.MOVETYPE_WALK;
            Utilities.SetStateChanged(pawn, "CBaseEntity", "m_MoveType");
            pawn.ActualMoveType = MoveType_t.MOVETYPE_WALK;
            RenderUtils.ResetTint(pawn);
            state.IsIceTinted = false;
        }

        private PlayerDayState GetState(CCSPlayerController player)
        {
            if (!_states.TryGetValue(player.Slot, out var state))
            {
                state = new PlayerDayState();
                _states[player.Slot] = state;
            }
            return state;
        }

        private static float VectorLength(Vector v) =>
            (float)Math.Sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);

        private static Vector AnglesToForward(QAngle angles)
        {
            double pitch = angles.X * Math.PI / 180.0;
            double yaw = angles.Y * Math.PI / 180.0;
            float x = (float)(Math.Cos(pitch) * Math.Cos(yaw));
            float y = (float)(Math.Cos(pitch) * Math.Sin(yaw));
            return new Vector(x, y, 0);
        }
    }
}
