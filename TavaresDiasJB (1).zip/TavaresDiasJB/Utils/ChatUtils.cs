using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;

namespace TavaresDiasJB.Utils
{
    public static class ChatUtils
    {
        private static readonly string Prefix = $"{ChatColors.Gold}[TavaresJB]{ChatColors.Default}";

        public static void All(string message)
        {
            foreach (var player in Utilities.GetPlayers())
            {
                if (player.IsValid && !player.IsBot)
                    player.PrintToChat($" {Prefix} {message}");
            }
        }

        public static void To(CCSPlayerController player, string message)
        {
            if (player.IsValid && !player.IsBot)
                player.PrintToChat($" {Prefix} {message}");
        }

        // --- Mensagens prontas usadas nos dias ---

        public static void DayActivated(string dayName) =>
            All($"{ChatColors.Green}O dia {ChatColors.Yellow}{dayName}{ChatColors.Green} foi ativado pelo Warden!");

        public static void DayEnded(string dayName) =>
            All($"{ChatColors.LightRed}O dia {ChatColors.Yellow}{dayName}{ChatColors.LightRed} terminou.");

        public static void WardenAssigned(string wardenName) =>
            All($"{ChatColors.Blue}{wardenName}{ChatColors.Default} é agora o {ChatColors.Yellow}Warden{ChatColors.Default}!");

        public static void WardenLost() =>
            All($"{ChatColors.LightRed}O Warden morreu. Escreve {ChatColors.Yellow}!warden{ChatColors.LightRed} para reclamar o cargo.");

        public static void CrawlersReleased() =>
            All($"{ChatColors.Purple}Os Crawlers foram soltos!");

        public static void CtsReleasedFreezeTag() =>
            All($"{ChatColors.Purple}Os CTs foram libertados! A caça aos Ts começou.");

        public static void LivesRemaining(CCSPlayerController player, int lives) =>
            To(player, $"{ChatColors.Yellow}Foste congelado! {ChatColors.Default}Tens {ChatColors.Red}{lives}{ChatColors.Default} vida(s) restante(s).");

        public static void PlayerDiedFromLives(string playerName) =>
            All($"{ChatColors.Red}{playerName}{ChatColors.Default} perdeu todas as vidas e morreu.");

        public static void PlayerRescued(string rescuerName, string rescuedName, int livesLeft) =>
            All($"{ChatColors.Green}{rescuerName}{ChatColors.Default} salvou {ChatColors.Green}{rescuedName}{ChatColors.Default}! ({livesLeft} vida(s) restante(s))");
    }
}
