using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;

namespace TavaresDiasJB.Utils
{
    /// <summary>
    /// NOTA IMPORTANTE (depois de dois crashes reais em produção):
    /// player.RemoveWeapons() é um método nativo do CounterStrikeSharp com um
    /// historial confirmado de crashar servidores CS2 (ver issue #250 do
    /// CounterStrikeSharp, e um crash report independente do RetakesPlugin com o
    /// mesmo padrão — chamado em vários jogadores logo no início de uma
    /// ronda/dia). Por isso NUNCA usamos player.RemoveWeapons() neste projeto.
    /// Em vez disso, removemos arma a arma via RemoveItemByDesignerName, que passa
    /// pelo caminho do ItemServices em vez de destruir entidades em bruto.
    /// </summary>
    public static class WeaponUtils
    {
        public static void SafeRemoveAllWeapons(CCSPlayerController player)
        {
            var pawn = player.PlayerPawn.Value;
            if (pawn == null) return;

            var weaponServices = pawn.WeaponServices;
            if (weaponServices == null) return;

            // Copiar para uma lista antes de remover, para não mexer na coleção
            // enquanto a percorremos.
            var designerNames = new List<string>();
            foreach (var weaponHandle in weaponServices.MyWeapons)
            {
                var weapon = weaponHandle.Value;
                if (weapon == null || !weapon.IsValid) continue;

                var name = weapon.DesignerName;
                if (!string.IsNullOrEmpty(name))
                {
                    designerNames.Add(name);
                }
            }

            foreach (var name in designerNames)
            {
                player.RemoveItemByDesignerName(name);
            }
        }
    }
}
