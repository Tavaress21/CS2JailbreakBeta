using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;
using TavaresDiasJB.Utils;

namespace TavaresDiasJB
{
    /// <summary>
    /// Sistema simples de Warden: o primeiro CT a escrever !warden fica Warden.
    /// Se o Warden morrer, o cargo fica vago até outro CT reclamar com !warden.
    /// Reseta a cada ronda nova.
    /// </summary>
    public class WardenManager
    {
        public CCSPlayerController? CurrentWarden { get; private set; }

        public bool HasWarden => CurrentWarden != null && CurrentWarden.IsValid && CurrentWarden.PlayerPawn.Value != null
                                  && CurrentWarden.PlayerPawn.Value.Health > 0;

        public bool IsWarden(CCSPlayerController player) =>
            HasWarden && CurrentWarden!.Slot == player.Slot;

        /// <summary>Tenta atribuir o Warden a este jogador. Retorna false se já houver Warden ou se não for CT.</summary>
        public bool TryClaim(CCSPlayerController player)
        {
            if (player.Team != CsTeam.CounterTerrorist)
            {
                ChatUtils.To(player, $"{ChatColors.Red}Só Counter-Terrorists podem ser Warden.");
                return false;
            }

            if (HasWarden)
            {
                ChatUtils.To(player, $"{ChatColors.Red}Já existe um Warden nesta ronda.");
                return false;
            }

            CurrentWarden = player;
            ChatUtils.WardenAssigned(player.PlayerName);
            return true;
        }

        /// <summary>Chamar quando um jogador morre; se for o Warden, liberta o cargo.</summary>
        public void OnPlayerDeath(CCSPlayerController victim)
        {
            if (CurrentWarden != null && CurrentWarden.Slot == victim.Slot)
            {
                CurrentWarden = null;
                ChatUtils.WardenLost();
            }
        }

        public void ResetForNewRound()
        {
            CurrentWarden = null;
        }
    }
}
