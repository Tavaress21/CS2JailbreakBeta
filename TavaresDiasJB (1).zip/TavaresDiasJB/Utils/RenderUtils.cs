using System.Drawing;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils; // RenderMode_t (mesmo módulo de onde vem MoveType_t)

namespace TavaresDiasJB.Utils
{
    /// <summary>
    /// NOTA DE VERIFICAÇÃO: os nomes exatos dos schema fields (m_clrRender, m_nRenderMode)
    /// e o método SetStateChanged já são usados por vários plugins CounterStrikeSharp
    /// públicos (ex: plugins de "invisible player"), mas se a tua build tiver uma
    /// versão diferente do CounterStrikeSharp, confirma que Utilities.SetStateChanged
    /// existe com esta assinatura antes de compilar em produção.
    /// </summary>
    public static class RenderUtils
    {
        public static void SetAlpha(CBaseModelEntity entity, int alpha)
        {
            if (entity == null || !entity.IsValid) return;

            var color = entity.Render;
            entity.Render = Color.FromArgb(alpha, color.R, color.G, color.B);
            Utilities.SetStateChanged(entity, "CBaseModelEntity", "m_clrRender");
        }

        public static void MakeFullyInvisible(CBaseModelEntity entity) => SetAlpha(entity, 0);

        public static void MakeFullyVisible(CBaseModelEntity entity) => SetAlpha(entity, 255);

        /// <summary>Tint azulado de "congelado" (usado em NightCrawler e FreezeTag).</summary>
        public static void ApplyIceTint(CBaseModelEntity entity)
        {
            if (entity == null || !entity.IsValid) return;
            entity.Render = Color.FromArgb(255, 140, 200, 255); // azul gelo, alpha cheio
            Utilities.SetStateChanged(entity, "CBaseModelEntity", "m_clrRender");
        }

        /// <summary>Glow amarelo de invulnerabilidade pós-resgate (FreezeTag).</summary>
        public static void ApplyRescueGlow(CBaseModelEntity entity)
        {
            if (entity == null || !entity.IsValid) return;
            entity.Render = Color.FromArgb(255, 255, 230, 80); // amarelo
            Utilities.SetStateChanged(entity, "CBaseModelEntity", "m_clrRender");
        }

        public static void ResetTint(CBaseModelEntity entity)
        {
            if (entity == null || !entity.IsValid) return;
            entity.Render = Color.FromArgb(255, 255, 255, 255);
            Utilities.SetStateChanged(entity, "CBaseModelEntity", "m_clrRender");
        }

        // NOTA: alterar render color/alpha em ARMAS é um problema antigo e conhecido
        // do motor Source (já documentado desde CS:GO) — não funciona de forma
        // fiável, ao contrário do que acontece com o pawn do jogador. A técnica que
        // realmente funciona para armas é via input de entidade DisableDraw/EnableDraw.
        public static void SetWeaponVisible(CBaseEntity weapon, bool visible)
        {
            if (weapon == null || !weapon.IsValid) return;
            weapon.AcceptInput(visible ? "EnableDraw" : "DisableDraw");
        }

        // ------------------------------------------------------------------
        // BUG CORRIGIDO: "dá para ver a faca quando és o CT invisível no
        // NightCrawler". Investigação:
        //
        //  - Só usar DisableDraw (SetWeaponVisible acima) NÃO chega sempre.
        //    Isto está confirmado por relatos reais de bugs idênticos em
        //    plugins públicos CS2 de "jogador invisível": o WallhackPluginCS2
        //    (fork/reescrita do FunnyPlugin) lista explicitamente, como
        //    correção feita sobre a versão anterior, "invisible players no
        //    longer expose their world weapons, grenades, knives, or related
        //    world rendering" — ou seja, a versão anterior (que só usava
        //    DisableDraw, tal como este plugin fazia) tinha exatamente este
        //    bug.
        //  - O próprio FunnyPlugin (a versão original) documenta ainda outra
        //    causa concreta: facas com skin/StatTrak/nametag do inventário do
        //    jogador NÃO ficam escondidas com as técnicas normais, porque o
        //    contador do StatTrak e a gravação do nametag são desenhados por
        //    fora do modelo base da arma.
        //
        // Por isso aplicamos 3 camadas em conjunto (em vez de confiar só numa):
        //   1) DisableDraw / EnableDraw (o que já estava a ser usado)
        //   2) alpha 0 + RenderMode translúcido — m_clrRender só é respeitado
        //      pelo motor Source se o RenderMode não for kRenderNormal; sem
        //      isto, mudar só o alpha não tem efeito nenhum (bug clássico e
        //      muito comum em scripting para jogos Source/Source2).
        //   3) reset da arma para uma skin "vanilla" sem StatTrak/nametag
        //      (StripCosmetics), eliminando a causa descrita acima.
        //
        // NOTA DE VERIFICAÇÃO: "RenderMode"/RenderMode_t.kRenderTransColor e os
        // campos "FallbackPaintKit/FallbackSeed/FallbackWear/FallbackStatTrak"
        // são usados por vários plugins públicos de skins para CS2 nesta versão
        // do CounterStrikeSharp, mas confirma os nomes exatos contra a tua build
        // instalada se não compilar à primeira (podem ter mudado de nome entre
        // versões do CS#).
        public static void HideWeaponCompletely(CBasePlayerWeapon weapon)
        {
            if (weapon == null || !weapon.IsValid) return;

            weapon.AcceptInput("DisableDraw");

            weapon.Render = Color.FromArgb(0, 255, 255, 255);
            weapon.RenderMode = RenderMode_t.kRenderTransColor;
            Utilities.SetStateChanged(weapon, "CBaseModelEntity", "m_clrRender");
            Utilities.SetStateChanged(weapon, "CBaseModelEntity", "m_nRenderMode");

            StripCosmetics(weapon);
        }

        public static void ShowWeaponNormally(CBasePlayerWeapon weapon)
        {
            if (weapon == null || !weapon.IsValid) return;

            weapon.AcceptInput("EnableDraw");

            weapon.Render = Color.FromArgb(255, 255, 255, 255);
            weapon.RenderMode = RenderMode_t.kRenderNormal;
            Utilities.SetStateChanged(weapon, "CBaseModelEntity", "m_clrRender");
            Utilities.SetStateChanged(weapon, "CBaseModelEntity", "m_nRenderMode");
        }

        // Tira skin/StatTrak/nametag da arma (ver nota acima). Isto NÃO altera
        // dano, cadência, precisão nem nenhuma outra mecânica — só o aspeto
        // visual da arma, que de qualquer forma faz sentido ser neutro/controlado
        // pelo servidor durante um dia especial em vez de depender do inventário
        // de cada jogador.
        private static void StripCosmetics(CBasePlayerWeapon weapon)
        {
            try
            {
                weapon.FallbackPaintKit = 0;
                weapon.FallbackSeed = 0;
                weapon.FallbackWear = 0.0f;
                weapon.FallbackStatTrak = -1;

                Utilities.SetStateChanged(weapon, "CBasePlayerWeapon", "m_nFallbackPaintKit");
                Utilities.SetStateChanged(weapon, "CBasePlayerWeapon", "m_nFallbackSeed");
                Utilities.SetStateChanged(weapon, "CBasePlayerWeapon", "m_flFallbackWear");
                Utilities.SetStateChanged(weapon, "CBasePlayerWeapon", "m_nFallbackStatTrak");
            }
            catch
            {
                // Se estes campos não existirem/tiverem outro nome nesta build do
                // CS#, ignora em silêncio — as camadas 1) e 2) acima continuam a
                // aplicar-se na mesma e já resolvem a maioria dos casos.
            }
        }
    }
}
