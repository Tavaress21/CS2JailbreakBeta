using CounterStrikeSharp.API.Core;

namespace TavaresDiasJB
{
    /// <summary>
    /// Estado runtime associado a um jogador durante um Special Day.
    /// É recriado/limpo a cada ronda (ver TavaresDiasJB.OnRoundStart).
    /// </summary>
    public class PlayerDayState
    {
        // --- Comum ---
        public bool IsFrozen = false;              // incapacitado (não se pode mexer/disparar)
        public bool IsIceTinted = false;            // efeito visual "gelo" aplicado

        // --- NightCrawler (CTs) ---
        public bool HasWallHangAbility = false;
        public bool IsCurrentlyHanging = false;     // está agarrado à parede agora
        public CounterStrikeSharp.API.Modules.Utils.Vector? HangOrigin = null;
        public CounterStrikeSharp.API.Modules.Utils.Vector? LastOrigin = null; // para heurística de colisão

        // --- FreezeTag (Ts) ---
        public int LivesRemaining = 3;
        public bool IsRescueInvulnerable = false;   // 2s de invulnerabilidade pós-resgate (glow amarelo)

        public void ResetForNewRound()
        {
            IsFrozen = false;
            IsIceTinted = false;
            HasWallHangAbility = false;
            IsCurrentlyHanging = false;
            HangOrigin = null;
            LastOrigin = null;
            LivesRemaining = 3;
            IsRescueInvulnerable = false;
        }
    }
}
