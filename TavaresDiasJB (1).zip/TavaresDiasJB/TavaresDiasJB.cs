using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Menu;
using CounterStrikeSharp.API.Modules.Utils;
using Microsoft.Extensions.Logging;
using TavaresDiasJB.Days;
using TavaresDiasJB.Utils;

namespace TavaresDiasJB
{
    [MinimumApiVersion(200)]
    public class TavaresDiasJB : BasePlugin
    {
        public override string ModuleName => "TavaresDiasJB";
        public override string ModuleVersion => "0.2.0";
        public override string ModuleAuthor => "Tavares";
        public override string ModuleDescription => "TavaresDiasJB — Special Days para Jailbreak: !warden + !dias (NightCrawler / FreezeTag)";

        private readonly WardenManager _wardenManager = new();
        private readonly Dictionary<int, PlayerDayState> _playerStates = new();

        private IDayMode? _activeDay = null;
        private bool _dayLocked = false; // true assim que um dia é ativado, até o fim da ronda

        public override void Load(bool hotReload)
        {
            RegisterEventHandler<EventRoundStart>(OnRoundStart);
            RegisterEventHandler<EventRoundEnd>(OnRoundEnd);
            RegisterEventHandler<EventPlayerDeath>(OnPlayerDeath);
            RegisterEventHandler<EventPlayerHurt>(OnPlayerHurt);

            RegisterListener<Listeners.OnTick>(OnTick);

            Logger.LogInformation("TavaresDiasJB carregado.");
        }

        // ---------------- Comandos ----------------

        [ConsoleCommand("css_warden", "Reclama o cargo de Warden (se estiver vago)")]
        [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
        public void OnWardenCommand(CCSPlayerController? player, CommandInfo info)
        {
            if (player == null || !player.IsValid) return;
            _wardenManager.TryClaim(player);
        }

        [ConsoleCommand("css_dias", "Abre o menu de Special Days (apenas Warden)")]
        [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
        public void OnDiasCommand(CCSPlayerController? player, CommandInfo info)
        {
            if (player == null || !player.IsValid) return;

            if (!_wardenManager.IsWarden(player))
            {
                ChatUtils.To(player, $"{ChatColors.Red}Só o Warden pode escolher o dia.");
                return;
            }

            if (_dayLocked)
            {
                ChatUtils.To(player, $"{ChatColors.Red}Já existe um dia ativo.");
                return;
            }

            int aliveTs = Utilities.GetPlayers().Count(p => p.IsValid && p.PawnIsAlive && p.Team == CsTeam.Terrorist);
            if (aliveTs < 2)
            {
                ChatUtils.To(player, $"{ChatColors.Red}É preciso pelo menos 2 prisioneiros vivos para ativar um dia.");
                return;
            }

            OpenDayMenu(player);
        }

        private void OpenDayMenu(CCSPlayerController player)
        {
            // NOTA: assinatura do ChatMenu/MenuManager pode variar ligeiramente consoante
            // a versão do CounterStrikeSharp instalada — confirma contra a tua build se
            // não compilar à primeira.
            var menu = new ChatMenu("Special Days");

            menu.AddMenuOption("NightCrawler", (menuPlayer, option) =>
            {
                StartDay(new NightCrawlerDay(_playerStates, this));
            });

            menu.AddMenuOption("FreezeTag", (menuPlayer, option) =>
            {
                StartDay(new FreezeTagDay(_playerStates, this));
            });

            MenuManager.OpenChatMenu(player, menu);
        }

        private void StartDay(IDayMode day)
        {
            if (_dayLocked) return;

            _activeDay = day;
            _dayLocked = true;
            ChatUtils.DayActivated(day.Name);
            day.OnDayStart();
        }

        private void EndActiveDay()
        {
            if (_activeDay == null) return;

            ChatUtils.DayEnded(_activeDay.Name);
            _activeDay.OnDayEnd();
            _activeDay = null;
            // _dayLocked continua true até a ronda acabar, conforme pedido:
            // "bloquear novos !dias até a ronda atual acabar"
        }

        // ---------------- Ciclo de vida da ronda ----------------

        private HookResult OnRoundStart(EventRoundStart @event, GameEventInfo info)
        {
            // Bug corrigido: antes isto fazia "_activeDay = null" diretamente, sem chamar
            // OnDayEnd(). Se por algum motivo um round_start disparar sem um round_end
            // completo antes (reinícios, warmup, etc.), o dia anterior nunca era limpo:
            // timers ficavam vivos e efeitos (tint, freeze, invisibilidade) atravessavam
            // para a ronda seguinte. Agora garantimos sempre o cleanup antes de resetar.
            if (_activeDay != null)
            {
                _activeDay.OnDayEnd();
                _activeDay = null;
            }

            _wardenManager.ResetForNewRound();
            _playerStates.Clear();
            _dayLocked = false;
            return HookResult.Continue;
        }

        private HookResult OnRoundEnd(EventRoundEnd @event, GameEventInfo info)
        {
            if (_activeDay != null)
            {
                EndActiveDay();
            }
            _dayLocked = false;
            return HookResult.Continue;
        }

        private HookResult OnPlayerDeath(EventPlayerDeath @event, GameEventInfo info)
        {
            var victim = @event.Userid;
            if (victim == null || !victim.IsValid) return HookResult.Continue;

            _wardenManager.OnPlayerDeath(victim);
            _activeDay?.OnPlayerDeath(victim);

            if (_activeDay != null && _activeDay.IsFinished)
            {
                EndActiveDay();
            }

            return HookResult.Continue;
        }

        private HookResult OnPlayerHurt(EventPlayerHurt @event, GameEventInfo info)
        {
            if (_activeDay == null) return HookResult.Continue;

            var victim = @event.Userid;
            var attacker = @event.Attacker;
            string weapon = @event.Weapon ?? "";
            int damage = @event.DmgHealth;

            if (victim == null || !victim.IsValid) return HookResult.Continue;

            Logger.LogInformation("player_hurt durante dia ativo: victim={Victim}, attacker={Attacker}, weapon='{Weapon}', damage={Damage}",
                victim.PlayerName, attacker?.PlayerName ?? "null", weapon, damage);

            bool handled = _activeDay.OnPlayerHurt(victim, attacker, weapon, damage);

            if (handled && damage > 0)
            {
                // Anula o dano: devolve a vida que foi retirada.
                // NOTA: o dia pode ter matado o jogador dentro do próprio OnPlayerHurt
                // (ex: FreezeTag ao perder a 3ª vida). Por isso confirmamos que o pawn
                // ainda está vivo e válido antes de mexer na vida, e protegemos com
                // try/catch — escrever em memória de uma entidade a meio da morte pode
                // lançar exceção consoante a versão do CS#.
                try
                {
                    var pawn = victim.PlayerPawn.Value;
                    if (pawn != null && pawn.IsValid && victim.PawnIsAlive && pawn.Health > 0)
                    {
                        pawn.Health = Math.Min(pawn.Health + damage, 100);
                        Utilities.SetStateChanged(pawn, "CBaseEntity", "m_iHealth");
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Falha ao restaurar vida após anular dano.");
                }
            }

            return HookResult.Continue;
        }

        private void OnTick()
        {
            if (_activeDay == null) return;

            _activeDay.OnTick();

            if (_activeDay.IsFinished)
            {
                EndActiveDay();
            }
        }
    }
}
